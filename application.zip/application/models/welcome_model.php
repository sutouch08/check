<?php
class Welcome_model extends CI_Model
{
  //public $db;
  //public $ms;
  public function __construct()
  {
    parent::__construct();
  }

  

}


 ?>
