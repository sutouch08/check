<?php $this->load->view('include/header'); ?>
<div class="row">
	<div class="col-sm-12">
    	<center><h1><i class="fa fa-lock fa-3x"></i></h1></center>
        <center><h3>Access Denied</h3></center>
        <center><h4>You don't have permission to access this resouces.</h4></center>
    </div>
</div>
<?php $this->load->view('include/footer'); ?>
<?php exit(); ?>
