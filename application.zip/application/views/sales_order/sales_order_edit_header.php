<div class="row">
  <!-- Left column -->
  <?php $this->load->view('sales_order/sales_order_edit_header_left'); ?>
  <!-- Right Column -->
  <?php $this->load->view('sales_order/sales_order_edit_header_right'); ?>

</div>
<hr class="padding-5">
