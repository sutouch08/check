<?php 
$this->load->view("include/header"); 
$this->load->view($view);
$this->load->view("include/footer");
?>

