       <!-- PAGE CONTENT ENDS -->
		  </div> <!-- pang content -->
	  </div><!-- main content inner -->
  </div><!-- main content -->

  <div class="footer hidden-print">
	  <div class="footer-inner">
			<div class="footer-content">
				<span class="bigger-120 orange">
					&copy; <?php echo getConfig('COMPANY_FULL_NAME');?>
				</span>
					&nbsp; &nbsp;
			</div>
			  <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
			  	<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
		  	</a>
	 </div><!-- footer inner-->
	</div><!-- /.footer -->
</div><!-- /.main-container -->


		<!-- page specific plugin scripts -->

		<!-- ace scripts -->
		<script type="text/javascript">
			window.jQuery || document.write("<script src='<?php echo base_url(); ?>assets/js/jquery.js'>"+"<"+"/script>");
		</script>

		<script src="<?php echo base_url(); ?>assets/js/ace/ace.sidebar.js?v=<?php echo date('Ymd'); ?>"></script>
		<script src="<?php echo base_url(); ?>assets/js/ace/ace.sidebar-scroll-1.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/ace/ace.submenu-hover.js"></script>
		<script src="<?php echo base_url(); ?>scripts/template.js?v=<?php echo date('Ymd'); ?>"></script>

	</body>

</html>
