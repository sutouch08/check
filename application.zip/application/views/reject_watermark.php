

<div style="width:100%; position:absolute; top:200px; left:0px; right:0px; color:red; text-align:center; z-index:100000; font-size:10vw; opacity:0.1;">
    REJECTED
</div>
